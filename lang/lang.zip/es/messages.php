<?php

return [

    'retrieved' => ':model recuperado con éxito.',
    'saved'     => ':model guardado con éxito.',
    'updated'   => ':model actualizado con éxito.',
    'deleted'   => ':model borrado con éxito.',
    'not_found' => ':model not encontrado',

];
