<?php

return [

    'retrieved' => 'تم جلب :model بنجاح.',
    'saved'     => 'تم حفظ :model بنجاح.',
    'updated'   => 'تم تعديل :model بنجاح.',
    'deleted'   => 'تم حذف :model بنجاح.',
    'not_found' => 'لم يتم العثور على :model.',

];
