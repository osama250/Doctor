<?php

return [

    'add_new'      => '添加',
    'cancel'       => '取消',
    'create'       => '创建',
    'edit'         => '编辑',
    'save'         => '保存',
    'delete'       => '删除',
    'detail'       => '详情',
    'back'         => '返回',
    'search'       => '搜索',
    'export'       => '导出',
    'print'        => '打印',
    'reset'        => '重置',
    'reload'       => '刷新',
    'action'       => '操作',
    'id'           => 'ID',
    'created_at'   => '创建时间',
    'updated_at'   => '更新时间',
    'deleted_at'   => '删除时间',
    'are_you_sure' => '您确定吗？',
];
