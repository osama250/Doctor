<?php

return [

    'retrieved' => '成功获取:model。',
    'saved'     => '已成功创建:model。',
    'updated'   => '已成功修改:model。',
    'deleted'   => '已成功删除:model。',
    'not_found' => '未找到:model。',

];
